<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\BusinessRegisterController;
use Illuminate\Support\Facades\Route;

// Route::get('login', [LoginController::class, 'showLoginForm'])->name('login');
// Route::post('sendOtp', [LoginController::class, 'sendOtp'])->name('sendOtp');
// Route::post('login', [LoginController::class, 'loginWithOtp'])->name('loginwithotp');
// Route::get('logout', [LoginController::class, 'logout'])->name("logout");

// Route::get('business/register', [BusinessRegisterController::class, 'create'])->name('business.register');
// Route::post('business/register', [BusinessRegisterController::class, 'store']);