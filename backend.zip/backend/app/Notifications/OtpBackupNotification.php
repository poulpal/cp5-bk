<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class OtpBackupNotification extends Notification
{
    use Queueable;

    public $otp;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($otp)
    {
        $this->otp = $otp;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['smsmelli'];
    }

    public function toSmsMelli($notifiable)
    {
        return [
            'text' => "پسورد ورود code: " . $this->otp . " \n poulpal.com",
        ];
    }
}
