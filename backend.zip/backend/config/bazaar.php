<?php

return [
    'apikey' => env('BAZAAR_API_KEY'),
];
