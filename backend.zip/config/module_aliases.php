<?php

return [
    // نگاشت اسلاگ‌های اشتباه/متعدد به اسلاگ واحد (canonical)
    'accounting-advanced'            => 'accounting-advanced-qr',
    'accounting-advanced-qr-module'  => 'accounting-advanced-qr',
    'acc-advanced'                   => 'accounting-advanced-qr',
    'accounting-general-advanced'    => 'accounting-advanced-qr',
];
