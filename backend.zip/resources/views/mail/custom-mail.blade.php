{!! $text !!}

<br>
{{ config('app.name') }}
<br>
<a href="https://cp.chargepal.ir"> cp.chargepal.ir </a>

