<?php

namespace App\Facades;

class Avanak extends \Illuminate\Support\Facades\Facade
{
    public static function getFacadeAccessor()
    {
        return 'avanak';
    }
}
