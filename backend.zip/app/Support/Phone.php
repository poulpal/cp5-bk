<?php

namespace App\Support;

class Phone
{
    /**
     * نرمال‌سازی موبایل ایران به فرمت 09XXXXXXXXX
     * ورودی‌های مجاز: 0912..., 912..., +98912..., 0098912..., 98 912..., با فاصله/خط‌تیره
     * خروجی: 11 رقم با صفر اول (مثلاً 09121234567) یا null اگر معتبر نبود.
     */
    public static function normalizeIranMobile(?string $input): ?string
    {
        if ($input === null) return null;

        // فقط رقم‌ها را نگه داریم
        $digits = preg_replace('/\D+/', '', $input ?? '');

        if ($digits === '') return null;

        // الگوهای ممکن: 0098xxxxxxxxxx | 98xxxxxxxxxx | 9xxxxxxxxx | 09xxxxxxxxx
        if (str_starts_with($digits, '0098')) {
            $digits = substr($digits, 4); // حذف 0098
        } elseif (str_starts_with($digits, '98')) {
            $digits = substr($digits, 2); // حذف 98
        }

        // حالا باید 10 یا 11 رقم باشد
        if (strlen($digits) === 10 && $digits[0] === '9') {
            // 9xxxxxxxxx → 09xxxxxxxxx
            $digits = '0' . $digits;
        }

        // اعتبارسنجی نهایی: 11 رقم و شروع با 0 و رقم دوم 9
        if (strlen($digits) === 11 && $digits[0] === '0' && $digits[1] === '9') {
            return $digits;
        }

        return null; // نامعتبر
    }

    /**
     * تبدیل داخلی ایران به E.164 (+98)
     * 0912... → +98912...
     */
    public static function toE164(?string $mobile): ?string
    {
        $n = self::normalizeIranMobile($mobile);
        if ($n === null) return null;
        // حذف صفر اول و چسباندن +98
        return '+98' . substr($n, 1);
    }

    /**
     * بررسی سریع معتبر بودن موبایل ایران
     */
    public static function isValidIranMobile(?string $input): bool
    {
        return self::normalizeIranMobile($input) !== null;
    }
}
